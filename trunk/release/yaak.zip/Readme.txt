yaak Ordner am Handy nach /sdcard/ kopieren
Yaak.apk installieren
Have fun!